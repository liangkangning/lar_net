<div class="callUs commom_left_right_padding">
    <div class="container">
        <div class="success">
        <div class="title"><h1 class="size1">Submitted successfully</h1></div>
        <div class="sub_title"><h2>Thank you for your message. We will respond to your inquiry as soon as possible!</h2></div>
        <div class="text">
        <p><strong>Dongguan Large Electronics Co., Ltd</strong><br>
            Email: info@large.net<br>
            Tel: 86-769-23182621
        </p>
        </div>
    </div>
</div>
</div>