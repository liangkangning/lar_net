<div class="p2 commom_left_right_padding ">
    <div class="title border_bottom"><h1 class="size1">History</h1></div>
    <div class="list">
        <ul>
            <li><div class="item">
                    <div class="left"><div class="text"><b class="size3">2017</b></div></div>
                    <div class="right">
                        <div class="pp size4"><span></span>Established special battery engineering research institute</div>
                        <div class="pp size4"><span></span>Had strategic cooperation with Dongguan University of Technology</div>
                        <div class="pp size4"><span></span>Passed Intellectual Property Management System Certification</div>
                    </div>
                </div></li>
            <li><div class="item">
                    <div class="left"><div class="text"><b class="size3">2015-2016</b></div></div>
                    <div class="right">
                        <div class="pp size4"><span></span>Recognized as "Dongguan Patent Advanced Enterprise" </div>
                        <div class="pp size4"><span></span>Recognized as "Guangdong Province Photovoltaic Energy Storage and Energy Internet Engineering Technology Research Center"</div>
                        <div class="pp size4"><span></span>Led in "the Innovation Team of Intelligent Optical Complementary Electricity Generation and <br>&nbsp;&nbsp; Its Energy Internet Technology Development and Industrialization"</div>
                        <div class="pp size4"><span></span>Signed strategic cooperation agreement with Central South University </div>
                        <div class="pp size4"><span></span>Passed BSCI Factory Qualification System Certification</div>
                    </div>
                </div></li>
            <li><div class="item">
                    <div class="left"><div class="text"><b class="size3">2012-2014</b></div></div>
                    <div class="right">
                        <div class="pp size4"><span></span>Awarded "Large taxpayer of industrial enterprises in Nancheng District of Dongguan"</div>
                        <div class="pp size4"><span></span>Awarded "Top Ten Growth Enterprises in Dongguan"</div>
                        <div class="pp size4"><span></span>Awarded "Dongguan Excellent Science Association"</div>
                        <div class="pp size4"><span></span>Set up joint laboratory of new energy with South China University of Technology</div>
                        <div class="pp size4"><span></span>Set up scientific research base for postgraduate with South China University of Technology</div>
                        <div class="pp size4"><span></span>Signed a strategic cooperation agreement with South China University of Technology</div>
                        <div class="pp size4"><span></span>Passed "OHSAS18000：2011 Occupational Health and Safety Management System Certification"</div>
                        <div class="pp size4"><span></span>Passed Apple MFI Factory Qualification System Certification</div>
                        <div class="pp size4"><span></span>Passed Wal-Mart Factory Qualification System Certification</div>
                    </div>
                </div></li>
            <li><div class="item">
                    <div class="left"><div class="text"><b class="size3">2009-2011</b></div></div>
                    <div class="right">
                        <div class="pp size4"><span></span>Recognized as "National High-Tech Enterprise"</div>
                        <div class="pp size4"><span></span>Recognized as "Private Technological Enterprise in Guangdong Province"</div>
                        <div class="pp size4"><span></span>Recognized as "Dongguan Private Technological Enterprise"</div>
                        <div class="pp size4"><span></span>Qualified as "Syndic Unit of the Chinese Battery Industry"</div>
                        <div class="pp size4"><span></span>Passed ISO14001:2004 Environmental System Certification</div>
                        <div class="pp size4"><span></span>Passed ISO9001:2008 Quality System Certification</div>
                    </div>
                </div></li>
            <li><div class="item">
                    <div class="left"><div class="text"><b class="size3">2006-2008</b></div></div>
                    <div class="right">
                        <div class="pp size4"><span></span>Recognized as "Dongguan patent cultivation enterprise"</div>
                        <div class="pp size4"><span></span>Signed the strategic cooperation agreement with the research institute of Tsinghua University </div>
                        <div class="pp size4"><span></span>Signed the strategic cooperation agreement with National Chemical Power Quality Inspection Center</div>
                        <div class="pp size4"><span></span>Established Science and Technology Enterprise Association </div>
                    </div>
                </div></li>
            <li><div class="item">
                    <div class="left"><div class="text"><b class="size3">2003-2005</b></div></div>
                    <div class="right">
                        <div class="pp size4"><span></span>Established Large (Yangzhou) Electronics Co., Ltd</div>
                        <div class="pp size4"><span></span>Established Large (HK) Electronics Co., Ltd </div>
                        <div class="pp size4"><span></span>Established Large (Shenzhen) Electronics Co., Ltd</div>
                    </div>
                </div></li>
            <li><div class="item">
                    <div class="left"><div class="text"><b class="size3">2002</b></div></div>
                    <div class="right">
                        <div class="pp size4"><span></span>Established Dongguan Large Electronics Co., Ltd. </div>
                        <div class="pp size4"><span></span>Created LARGE POWER brand</div>
                    </div>
                </div></li>
        </ul>
    </div>


</div>
