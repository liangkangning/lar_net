<section class="container error_content">
    <div class="content">
    <div class="title"><h1>404-Page Not Found</h1></div>
     <div class="sub_title">We’re sorry, the page you requested cannot be found.</div>
     <div class="text"><p>The URL may be misspelled or the page you're looking for is no longer available.<br>
             Please go back to our home page or use the search to find your desired information.</p>
     </div>
     <div class="go_back">
         <a href="/">Back Home</a>
     </div>
    </div>

</section>

