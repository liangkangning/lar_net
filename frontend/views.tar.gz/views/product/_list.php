<li class="col-xs-6 col-sm-3">

    <div class="item">

        <div class="img"><a href="<?= $model->url?>"><img  src="<?=$model->imageUrl?>" alt="<?=$model->title?>"  title="<?=$model->title?>"/></a></div>

        <div class="text"><p class="size4"><a href="<?= $model->url?>" title="<?=$model->title?>"><?= $model->title ?></a></p></div>

    </div>

</li>

